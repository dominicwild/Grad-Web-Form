module.exports = {
    cognito: {
        clientId: "2u9nin53f2tpesgbnjgf9u2d19",
        poolId: "eu-west-1_rqB2QZSvt",
        region: 'us-west-2'
    },
    api: {
        invokeUrl: "https://iq7a6rej2j.execute-api.eu-west-1.amazonaws.com/Stage",
        type: "aws" //Options [local, aws]
    }
}