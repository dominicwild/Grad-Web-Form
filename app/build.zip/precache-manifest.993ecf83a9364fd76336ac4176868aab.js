self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "bc49197074b5c82f34f0d08f40076724",
    "url": "/index.html"
  },
  {
    "revision": "50831b87dad7fe8668d1",
    "url": "/static/css/2.a866c86c.chunk.css"
  },
  {
    "revision": "4c932ad4ea3c44962e8b",
    "url": "/static/css/main.6c202557.chunk.css"
  },
  {
    "revision": "50831b87dad7fe8668d1",
    "url": "/static/js/2.0e3206af.chunk.js"
  },
  {
    "revision": "9c0ff7e7fb199c6a17fc4d289bb370d0",
    "url": "/static/js/2.0e3206af.chunk.js.LICENSE.txt"
  },
  {
    "revision": "4c932ad4ea3c44962e8b",
    "url": "/static/js/main.eb6ddb7c.chunk.js"
  },
  {
    "revision": "c27f76a36f8d51c29fd4",
    "url": "/static/js/runtime-main.7bc453c4.js"
  },
  {
    "revision": "eef67b5f20d1563a9942833b30536801",
    "url": "/static/media/DXC_Technology_logo.eef67b5f.svg"
  },
  {
    "revision": "fd9fa5bdeb602267566c5f3c24a6e9cd",
    "url": "/static/media/GT-Walsheim-Pro-Bold-Oblique.fd9fa5bd.ttf"
  },
  {
    "revision": "bc3cac084781d8105518d095fa6b4f8f",
    "url": "/static/media/GT-Walsheim-Pro-Bold.bc3cac08.ttf"
  },
  {
    "revision": "eed7d5c99f209fc1c3a62c2a4fa0ab3c",
    "url": "/static/media/GT-Walsheim-Pro-Light-Oblique.eed7d5c9.ttf"
  },
  {
    "revision": "6daeff877a8cd90badff68be0c754cc1",
    "url": "/static/media/GT-Walsheim-Pro-Light.6daeff87.ttf"
  },
  {
    "revision": "89c6cd724c79da24e26c289f9d55adf8",
    "url": "/static/media/GT-Walsheim-Pro-Regular-Oblique.89c6cd72.ttf"
  },
  {
    "revision": "8c8defcc9837e276d0657b5b9263a38c",
    "url": "/static/media/GT-Walsheim-Pro-Regular.8c8defcc.ttf"
  },
  {
    "revision": "0f0afa57a761686ad7865583f3b6c05a",
    "url": "/static/media/lantern.0f0afa57.jpg"
  },
  {
    "revision": "1b5c9c8826a0c4c14907839bbc5ccedf",
    "url": "/static/media/loading.1b5c9c88.svg"
  }
]);